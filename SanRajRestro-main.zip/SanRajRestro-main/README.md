# SanRajRestro
This project is a web-based application designed to streamline restaurant operations. It allows users to place food orders, make table reservations, and manage inventory efficiently. Built using Python and Django, the system provides a user-friendly interface for both customers and restaurant staff
